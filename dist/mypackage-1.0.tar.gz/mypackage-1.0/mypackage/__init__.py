import sys
sys.path.append('C:/Users/aaggu/mypackage')
from mypackage import myModule
